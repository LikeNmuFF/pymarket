# PythonAnywhere Deployment Guide
# ================================

## 1. Upload your project
Upload these files to PythonAnywhere (e.g. via the Files tab or git clone):
  team_generator/
    app.py
    requirements.txt
    templates/
      index.html

## 2. Install dependencies (in a Bash console)
  pip install flask --user
  # OR if using a virtualenv:
  mkvirtualenv teamgen --python=python3.10
  pip install flask

## 3. Configure Web App
- Go to Web tab → Add a new web app
- Choose "Manual configuration" → Python 3.10
- Set Source code: /home/<yourusername>/team_generator
- Set Working directory: /home/<yourusername>/team_generator

## 4. Edit the WSGI file (auto-created by PythonAnywhere)
Replace contents with:

  import sys
  sys.path.insert(0, '/home/<yourusername>/team_generator')
  from app import app as application

## 5. Reload your web app
Click the green Reload button in the Web tab.
Your app will be live at: https://<yourusername>.pythonanywhere.com
