from flask import Flask, render_template, request, jsonify, session, Response
import random
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-change-in-prod')

# ──────────────────────────────────────────────
# Routes
# ──────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/generate', methods=['POST'])
def generate():
    data = request.get_json()
    players      = data.get('players', [])
    num_teams    = int(data.get('num_teams', 2))
    balance_mode = data.get('balance_mode', 'random')
    team_names   = data.get('team_names', [])
    reroll_team  = data.get('reroll_team', None)
    current_teams = data.get('current_teams', None)

    if not players:
        return jsonify({'error': 'No players provided'}), 400
    if num_teams < 2:
        return jsonify({'error': 'Need at least 2 teams'}), 400
    if num_teams > len(players):
        return jsonify({'error': 'More teams than players'}), 400

    # Separate locked vs free
    locked = {}
    free = []
    for p in players:
        lt = p.get('locked_team')
        if lt is not None and str(lt).strip() != '' and int(lt) >= 0:
            locked.setdefault(int(lt), []).append(p)
        else:
            free.append(p)

    if reroll_team is not None and current_teams:
        result = reroll_one(current_teams, int(reroll_team), free)
        save_history(result['teams'], result['balance_score'], balance_mode)
        return jsonify(result)

    teams_raw = build_teams(free, locked, num_teams, balance_mode)
    result    = format_teams(teams_raw, team_names, num_teams)
    score     = balance_score(teams_raw)
    save_history(result, score, balance_mode)
    return jsonify({'teams': result, 'balance_score': score})


@app.route('/history', methods=['GET'])
def get_history():
    return jsonify({'history': session.get('history', [])})


@app.route('/history/clear', methods=['POST'])
def clear_history():
    session['history'] = []
    return jsonify({'ok': True})


@app.route('/export/csv', methods=['POST'])
def export_csv():
    data  = request.get_json()
    teams = data.get('teams', [])
    lines = ['Team,Player,Skill,Gender']
    for team in teams:
        for m in team['members']:
            lines.append(f"{team['name']},{m['name']},{m.get('skill','')},{m.get('gender','')}")
    return Response('\n'.join(lines), mimetype='text/csv',
                    headers={'Content-Disposition': 'attachment; filename=teams.csv'})


# ──────────────────────────────────────────────
# Core logic
# ──────────────────────────────────────────────

def build_teams(free, locked, num_teams, balance_mode):
    teams = [list(locked.get(i, [])) for i in range(num_teams)]
    if balance_mode == 'skill':
        snake_fill(teams, sorted(free, key=lambda x: int(x.get('skill', 5)), reverse=True))
    elif balance_mode == 'gender':
        males   = [p for p in free if p.get('gender','').lower() in ('m','male','boy')]
        females = [p for p in free if p.get('gender','').lower() in ('f','female','girl')]
        others  = [p for p in free if p not in males and p not in females]
        for grp in (males, females, others):
            random.shuffle(grp)
            snake_fill(teams, grp)
    else:
        random.shuffle(free)
        round_robin(teams, free)
    return teams


def snake_fill(teams, players):
    n, direction, idx = len(teams), 1, 0
    for p in players:
        teams[idx].append(p)
        idx += direction
        if idx >= n:   direction = -1; idx = n - 1
        elif idx < 0:  direction =  1; idx = 0


def round_robin(teams, players):
    for i, p in enumerate(players):
        teams[i % len(teams)].append(p)


def reroll_one(current_teams, reroll_idx, free_players):
    """Swap the unlocked members of one team with random players from other teams."""
    # Build flat pool of (team_idx, member) for unlocked players NOT in target team
    pool = []
    for i, t in enumerate(current_teams):
        if i == reroll_idx:
            continue
        for m in t['members']:
            if m.get('locked_team') is None or str(m.get('locked_team')).strip() == '':
                pool.append((i, m))

    # Unlocked members of target team
    target_unlocked = [m for m in current_teams[reroll_idx]['members']
                       if m.get('locked_team') is None or str(m.get('locked_team')).strip() == '']

    random.shuffle(pool)
    swaps = pool[:len(target_unlocked)]

    # Clone teams
    new_teams = [{'name': t['name'], 'members': list(t['members'])} for t in current_teams]

    # Remove swapped-out members from their source teams
    for src_idx, m in swaps:
        new_teams[src_idx]['members'] = [x for x in new_teams[src_idx]['members'] if x['name'] != m['name']]

    # Remove unlocked members from target
    new_teams[reroll_idx]['members'] = [m for m in new_teams[reroll_idx]['members']
                                         if not (m.get('locked_team') is None or str(m.get('locked_team')).strip() == '')]

    # Add swapped players to target
    for _, m in swaps:
        new_teams[reroll_idx]['members'].append(m)

    # Return displaced target members to source teams
    for i, (src_idx, _) in enumerate(swaps):
        if i < len(target_unlocked):
            new_teams[src_idx]['members'].append(target_unlocked[i])

    # Recalculate stats
    for t in new_teams:
        skills = [int(m.get('skill', 5)) for m in t['members']]
        t['avg_skill'] = round(sum(skills)/len(skills), 1) if skills else 0
        t['size'] = len(t['members'])

    raw   = [[{'skill': int(m.get('skill',5))} for m in t['members']] for t in new_teams]
    return {'teams': new_teams, 'balance_score': balance_score(raw)}


def format_teams(teams_raw, team_names, num_teams):
    result = []
    for i, team in enumerate(teams_raw):
        skills = [int(p.get('skill', 5)) for p in team]
        avg    = round(sum(skills)/len(skills), 1) if skills else 0
        name   = (team_names[i].strip() if i < len(team_names) and team_names[i].strip()
                  else f'Team {i+1}')
        result.append({
            'name': name,
            'members': [{'name': p['name'], 'skill': int(p.get('skill',5)),
                         'gender': p.get('gender',''), 'locked_team': p.get('locked_team')} for p in team],
            'avg_skill': avg,
            'size': len(team)
        })
    return result


def balance_score(teams_raw):
    if len(teams_raw) < 2:
        return 100
    avgs = [sum(int(p.get('skill',5)) for p in t)/len(t) for t in teams_raw if t]
    if not avgs:
        return 100
    spread = max(avgs) - min(avgs)
    return max(0, round(100 - (spread / 9) * 100))


def save_history(teams, score, mode):
    history = session.get('history', [])
    history.insert(0, {
        'timestamp': datetime.now().strftime('%b %d, %H:%M'),
        'teams': teams,
        'balance_score': score,
        'mode': mode,
        'player_count': sum(t['size'] for t in teams)
    })
    session['history'] = history[:20]


if __name__ == '__main__':
    app.run(debug=True)
