from flask import Flask, render_template, jsonify
import urllib.request
import urllib.error
import json
import time
import random

app = Flask(__name__)

# ─── Mock Data ────────────────────────────────────────────────────────────────

MOCK_POSTS = [
    {
        "id": "mock_1",
        "source": "mock",
        "platform": "Demo",
        "author": "alice_dev",
        "avatar": "A",
        "content": "Just shipped a new feature! Really excited about how the API integration turned out 🚀",
        "timestamp": int(time.time()) - 600,
        "url": "#",
        "likes": 42,
        "comments": 8,
        "label": "DEMO"
    },
    {
        "id": "mock_2",
        "source": "mock",
        "platform": "Demo",
        "author": "techblog",
        "avatar": "T",
        "content": "Python 3.13 performance benchmarks are looking wild. CPython free-threading is a game changer.",
        "timestamp": int(time.time()) - 1800,
        "url": "#",
        "likes": 117,
        "comments": 23,
        "label": "DEMO"
    },
    {
        "id": "mock_3",
        "source": "mock",
        "platform": "Demo",
        "author": "opendev",
        "avatar": "O",
        "content": "Reminder: PythonAnywhere free tier supports Flask, Django, and FastAPI out of the box. Great for prototypes!",
        "timestamp": int(time.time()) - 3600,
        "url": "#",
        "likes": 89,
        "comments": 14,
        "label": "DEMO"
    },
]

# ─── Reddit ───────────────────────────────────────────────────────────────────

def fetch_reddit(subreddit="programming", limit=10):
    url = f"https://www.reddit.com/r/{subreddit}/hot.json?limit={limit}"
    req = urllib.request.Request(url, headers={"User-Agent": "SocialDashboard/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode())
        posts = []
        for item in data["data"]["children"]:
            p = item["data"]
            posts.append({
                "id": "reddit_" + p["id"],
                "source": "reddit",
                "platform": f"r/{p['subreddit']}",
                "author": p["author"],
                "avatar": p["author"][0].upper() if p["author"] else "R",
                "content": p["title"] + (f"\n\n{p['selftext'][:200]}…" if p.get("selftext") else ""),
                "timestamp": int(p["created_utc"]),
                "url": "https://reddit.com" + p["permalink"],
                "likes": p["score"],
                "comments": p["num_comments"],
                "label": "REDDIT"
            })
        return posts
    except Exception as e:
        return [{"id": "reddit_err", "source": "reddit", "platform": "Reddit", "author": "system",
                 "avatar": "!", "content": f"Could not load Reddit: {e}",
                 "timestamp": int(time.time()), "url": "#", "likes": 0, "comments": 0, "label": "REDDIT"}]


# ─── Mastodon ─────────────────────────────────────────────────────────────────

def fetch_mastodon(instance="mastodon.social", limit=10):
    url = f"https://{instance}/api/v1/timelines/public?limit={limit}"
    req = urllib.request.Request(url, headers={"User-Agent": "SocialDashboard/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode())
        posts = []
        for p in data:
            acct = p.get("account", {})
            # Strip HTML tags from content
            raw = p.get("content", "")
            import re
            clean = re.sub(r"<[^>]+>", "", raw).strip()
            posts.append({
                "id": "masto_" + p["id"],
                "source": "mastodon",
                "platform": "Mastodon",
                "author": acct.get("acct", "unknown"),
                "avatar": (acct.get("display_name") or acct.get("acct", "M"))[0].upper(),
                "content": clean[:280],
                "timestamp": int(time.mktime(time.strptime(p["created_at"][:19], "%Y-%m-%dT%H:%M:%S"))),
                "url": p.get("url", "#"),
                "likes": p.get("favourites_count", 0),
                "comments": p.get("replies_count", 0),
                "label": "MASTODON"
            })
        return posts
    except Exception as e:
        return [{"id": "masto_err", "source": "mastodon", "platform": "Mastodon", "author": "system",
                 "avatar": "!", "content": f"Could not load Mastodon: {e}",
                 "timestamp": int(time.time()), "url": "#", "likes": 0, "comments": 0, "label": "MASTODON"}]


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/feed")
def feed():
    posts = []
    posts += MOCK_POSTS
    posts += fetch_reddit("programming", 8)
    posts += fetch_mastodon("mastodon.social", 8)
    posts.sort(key=lambda x: x["timestamp"], reverse=True)
    return jsonify(posts)


@app.route("/api/feed/<source>")
def feed_source(source):
    if source == "mock":
        return jsonify(MOCK_POSTS)
    elif source == "reddit":
        return jsonify(fetch_reddit("programming", 12))
    elif source == "mastodon":
        return jsonify(fetch_mastodon("mastodon.social", 12))
    return jsonify([])


if __name__ == "__main__":
    app.run(debug=True)
