# 🚀 Deploy to PythonAnywhere — Step-by-Step

## 1. Sign up (free)
Go to https://www.pythonanywhere.com and create a free account.

## 2. Upload your files
In the PythonAnywhere dashboard:
- Go to **Files** tab
- Create folder: `/home/yourusername/social_dashboard/`
- Upload: `app.py`, `requirements.txt`, `wsgi.py`
- Create subfolder: `templates/`
- Upload: `templates/index.html`

OR use the **Bash console** to clone/upload via git:
```bash
git clone https://github.com/yourrepo/social_dashboard.git
```

## 3. Install dependencies
Open a **Bash console** and run:
```bash
cd ~/social_dashboard
pip3.10 install --user flask
```

## 4. Create a Web App
- Go to **Web** tab → **Add a new web app**
- Choose: **Manual configuration** → **Python 3.10**
- Set **Source code**: `/home/yourusername/social_dashboard`
- Set **Working directory**: `/home/yourusername/social_dashboard`

## 5. Configure WSGI
- Click on the WSGI configuration file link (e.g. `/var/www/yourusername_pythonanywhere_com_wsgi.py`)
- Delete all existing content
- Paste the contents of `wsgi.py` (replacing `yourusername` with your actual username)
- Save

## 6. Reload & visit
- Click **Reload** on the Web tab
- Visit: `https://yourusername.pythonanywhere.com`

---

## ✅ Free Tier Limits
- Reddit API: ✅ whitelisted on PythonAnywhere free
- Mastodon (mastodon.social): ✅ whitelisted
- 512MB storage, 1 web app, sleeps after inactivity (wakes on request)

## 🔧 Customization
- Change Reddit subreddit: edit `fetch_reddit("programming")` in `app.py`
- Change Mastodon instance: edit `fetch_mastodon("mastodon.social")` in `app.py`
- Auto-refresh interval: edit `setInterval(loadFeed, 120000)` in `index.html` (ms)
