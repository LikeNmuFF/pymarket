# ──────────────────────────────────────────────────────────────
#  PythonAnywhere WSGI configuration
#  Place this content in your WSGI config file on PythonAnywhere
#  (found at: Web tab → WSGI configuration file)
# ──────────────────────────────────────────────────────────────

import sys
import os

# Replace 'yourusername' with your actual PythonAnywhere username
project_home = '/home/yourusername/social_dashboard'

if project_home not in sys.path:
    sys.path.insert(0, project_home)

os.chdir(project_home)

from app import app as application  # noqa
