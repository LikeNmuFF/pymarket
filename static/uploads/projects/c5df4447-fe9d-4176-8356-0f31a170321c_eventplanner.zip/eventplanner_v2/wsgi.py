import sys, os

# Replace 'yourusername' with your actual PythonAnywhere username
project_home = '/home/yourusername/eventplanner'
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# Strongly recommended: set a real secret key
# os.environ['SECRET_KEY'] = 'replace-with-a-long-random-string'

from app import app as application
