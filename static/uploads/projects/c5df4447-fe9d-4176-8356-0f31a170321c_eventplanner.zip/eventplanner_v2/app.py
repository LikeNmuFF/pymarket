from flask import (Flask, render_template, request, redirect,
                   url_for, flash, abort, send_from_directory, jsonify)
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from markupsafe import Markup, escape
import uuid, os, qrcode, io, base64

app = Flask(__name__)
app.config['SECRET_KEY']                  = os.environ.get('SECRET_KEY', 'dev-secret-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI']     = os.environ.get('DATABASE_URL', 'sqlite:///events.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAX_CONTENT_LENGTH']          = 4 * 1024 * 1024   # 4 MB upload limit
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
ALLOWED_EXT   = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

db = SQLAlchemy(app)

# ── Helpers ───────────────────────────────────────────────────────────────────

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT

def safe_filename(filename):
    ext  = filename.rsplit('.', 1)[1].lower()
    return f"{uuid.uuid4().hex}.{ext}"

# ── Template filters ──────────────────────────────────────────────────────────

@app.template_filter('nl2br')
def nl2br(value):
    return Markup(escape(value).replace('\n', Markup('<br>')))

@app.template_filter('fmtdate')
def fmtdate(dt, fmt='long'):
    day  = str(dt.day)
    hour = dt.hour % 12 or 12
    mins = dt.strftime('%M')
    ampm = 'AM' if dt.hour < 12 else 'PM'
    if fmt == 'long':
        return dt.strftime('%A, %B ') + day + ', ' + dt.strftime('%Y') + \
               ' at ' + str(hour) + ':' + mins + ' ' + ampm
    if fmt == 'short':
        return dt.strftime('%A, %B ') + day + ', ' + dt.strftime('%Y')
    if fmt == 'time':
        return str(hour) + ':' + mins + ' ' + ampm
    if fmt == 'monthday':
        return dt.strftime('%b ') + day
    return str(dt)

# ── Models ────────────────────────────────────────────────────────────────────

class Event(db.Model):
    id           = db.Column(db.Integer, primary_key=True)
    token        = db.Column(db.String(36), unique=True, nullable=False,
                             default=lambda: str(uuid.uuid4()))
    title        = db.Column(db.String(200), nullable=False)
    description  = db.Column(db.Text)
    date         = db.Column(db.DateTime, nullable=False)
    location     = db.Column(db.String(300))
    host_name    = db.Column(db.String(100), nullable=False)
    host_email   = db.Column(db.String(200), nullable=False)
    cover_image  = db.Column(db.String(200))          # filename in uploads/
    capacity     = db.Column(db.Integer)              # None = unlimited
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)
    rsvps        = db.relationship('RSVP',    backref='event', lazy=True,
                                   cascade='all, delete-orphan')
    comments     = db.relationship('Comment', backref='event', lazy=True,
                                   cascade='all, delete-orphan')

    @property
    def going(self):
        return [r for r in self.rsvps if r.status == 'going']

    @property
    def not_going(self):
        return [r for r in self.rsvps if r.status == 'not_going']

    @property
    def maybe(self):
        return [r for r in self.rsvps if r.status == 'maybe']

    @property
    def waitlist(self):
        return [r for r in self.rsvps if r.status == 'waitlist']

    @property
    def spots_left(self):
        if self.capacity is None:
            return None
        taken = len(self.going)
        return max(0, self.capacity - taken)

    @property
    def is_full(self):
        return self.capacity is not None and self.spots_left == 0


class RSVP(db.Model):
    id         = db.Column(db.Integer, primary_key=True)
    event_id   = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    name       = db.Column(db.String(100), nullable=False)
    email      = db.Column(db.String(200), nullable=False)
    status     = db.Column(db.String(20),  nullable=False)
    message    = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Comment(db.Model):
    id         = db.Column(db.Integer, primary_key=True)
    event_id   = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    name       = db.Column(db.String(100), nullable=False)
    body       = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# ── Routes ────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)


@app.route('/create', methods=['GET', 'POST'])
def create_event():
    if request.method == 'POST':
        title       = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        date_str    = request.form.get('date', '')
        location    = request.form.get('location', '').strip()
        host_name   = request.form.get('host_name', '').strip()
        host_email  = request.form.get('host_email', '').strip()
        capacity_s  = request.form.get('capacity', '').strip()

        errors = []
        if not title:      errors.append('Event title is required.')
        if not date_str:   errors.append('Event date & time is required.')
        if not host_name:  errors.append('Your name is required.')
        if not host_email: errors.append('Your email is required.')

        event_date = None
        if date_str:
            try:
                event_date = datetime.strptime(date_str, '%Y-%m-%dT%H:%M')
            except ValueError:
                errors.append('Invalid date format.')

        capacity = None
        if capacity_s:
            try:
                capacity = int(capacity_s)
                if capacity < 1:
                    raise ValueError
            except ValueError:
                errors.append('Capacity must be a positive number.')

        if errors:
            for e in errors:
                flash(e, 'error')
            return render_template('create.html', form_data=request.form)

        # Handle cover image
        cover_image = None
        file = request.files.get('cover_image')
        if file and file.filename and allowed_file(file.filename):
            fname = safe_filename(file.filename)
            file.save(os.path.join(UPLOAD_FOLDER, fname))
            cover_image = fname

        event = Event(title=title, description=description, date=event_date,
                      location=location, host_name=host_name, host_email=host_email,
                      cover_image=cover_image, capacity=capacity)
        db.session.add(event)
        db.session.commit()
        flash('Event created successfully! Share the link below.', 'success')
        return redirect(url_for('manage_event', token=event.token))

    return render_template('create.html', form_data={})


@app.route('/event/<token>')
def view_event(token):
    event = Event.query.filter_by(token=token).first_or_404()
    return render_template('event.html', event=event)


@app.route('/event/<token>/rsvp', methods=['POST'])
def rsvp(token):
    event   = Event.query.filter_by(token=token).first_or_404()
    name    = request.form.get('name', '').strip()
    email   = request.form.get('email', '').strip()
    status  = request.form.get('status', '')
    message = request.form.get('message', '').strip()

    errors = []
    if not name:  errors.append('Your name is required.')
    if not email: errors.append('Your email is required.')
    if status not in ('going', 'not_going', 'maybe'):
        errors.append('Please choose a valid RSVP status.')

    if errors:
        for e in errors: flash(e, 'error')
        return redirect(url_for('view_event', token=token))

    # If event is full and they want to go, put them on waitlist
    if status == 'going' and event.is_full:
        existing = RSVP.query.filter_by(event_id=event.id, email=email).first()
        if not existing or existing.status != 'going':
            status = 'waitlist'
            flash('The event is at capacity — you have been added to the waitlist!', 'success')

    existing = RSVP.query.filter_by(event_id=event.id, email=email).first()
    if existing:
        existing.name    = name
        existing.status  = status
        existing.message = message
        if status != 'waitlist':
            flash('Your RSVP has been updated!', 'success')
    else:
        db.session.add(RSVP(event_id=event.id, name=name,
                            email=email, status=status, message=message))
        if status != 'waitlist':
            flash('Thanks for your RSVP!', 'success')

    db.session.commit()
    return redirect(url_for('view_event', token=token))


@app.route('/event/<token>/comment', methods=['POST'])
def post_comment(token):
    event = Event.query.filter_by(token=token).first_or_404()
    name  = request.form.get('comment_name', '').strip()
    body  = request.form.get('comment_body', '').strip()
    if not name or not body:
        flash('Name and comment are required.', 'error')
    else:
        db.session.add(Comment(event_id=event.id, name=name, body=body))
        db.session.commit()
        flash('Comment posted!', 'success')
    return redirect(url_for('view_event', token=token) + '#comments')


@app.route('/manage/<token>')
def manage_event(token):
    event = Event.query.filter_by(token=token).first_or_404()
    qr_data = _make_qr(request.host_url + 'event/' + event.token)
    return render_template('manage.html', event=event, qr_data=qr_data)


@app.route('/manage/<token>/delete-rsvp/<int:rsvp_id>', methods=['POST'])
def delete_rsvp(token, rsvp_id):
    event      = Event.query.filter_by(token=token).first_or_404()
    rsvp_entry = db.session.get(RSVP, rsvp_id) or abort(404)
    if rsvp_entry.event_id != event.id: abort(403)
    db.session.delete(rsvp_entry)
    db.session.commit()
    flash('RSVP removed.', 'success')
    return redirect(url_for('manage_event', token=token))


@app.route('/manage/<token>/delete-comment/<int:comment_id>', methods=['POST'])
def delete_comment(token, comment_id):
    event   = Event.query.filter_by(token=token).first_or_404()
    comment = db.session.get(Comment, comment_id) or abort(404)
    if comment.event_id != event.id: abort(403)
    db.session.delete(comment)
    db.session.commit()
    flash('Comment removed.', 'success')
    return redirect(url_for('manage_event', token=token))


@app.route('/manage/<token>/print-guests')
def print_guests(token):
    event = Event.query.filter_by(token=token).first_or_404()
    now   = datetime.utcnow().strftime('%B %d, %Y')
    return render_template('print_guests.html', event=event, now=now)


# ── QR helper ─────────────────────────────────────────────────────────────────

def _make_qr(url):
    qr = qrcode.QRCode(box_size=6, border=2,
                       error_correction=qrcode.constants.ERROR_CORRECT_M)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#1a1612", back_color="white")
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()


# ── Init ──────────────────────────────────────────────────────────────────────

with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
