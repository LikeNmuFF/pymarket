# Soirée v2 — Event Planning & RSVP App

## New in v2
- 🖼️ Cover photo upload on event pages
- 🎟️ Capacity limit with automatic waitlist
- 💬 Guest comments/discussion board
- 📱 QR code invite (view + download in host dashboard)
- 🌙 Dark mode toggle (remembers preference)
- 📱 Mobile-responsive hamburger menu
- 🖨️ Printable guest list (with check-in checkboxes)
- 🎨 Completely redesigned UI

## Deploy to PythonAnywhere (Free — no credit card)

### 1. Sign up at pythonanywhere.com (Beginner plan)

### 2. Upload files
Dashboard → Files → create `/home/<username>/eventplanner/`  
Upload all files, maintaining the folder structure:
```
eventplanner/
  app.py
  wsgi.py
  requirements.txt
  templates/
    base.html  create.html  event.html
    manage.html  print_guests.html  index.html
  static/
    uploads/   ← created automatically
```

### 3. Install dependencies (Bash console)
```bash
pip3.10 install --user flask flask-sqlalchemy "qrcode[pil]" pillow
```

### 4. Create Web App
Web tab → Add new web app → Manual configuration → Python 3.10

- Source code: `/home/<username>/eventplanner`
- Working directory: `/home/<username>/eventplanner`

### 5. Edit WSGI file
Click the WSGI file link in the Web tab, replace contents:
```python
import sys, os
project_home = '/home/YOURUSERNAME/eventplanner'
if project_home not in sys.path:
    sys.path.insert(0, project_home)
os.environ['SECRET_KEY'] = 'pick-a-long-random-string-here'
from app import app as application
```

### 6. Reload → Done!
Your site is live at: `https://yourusername.pythonanywhere.com`

---
## Notes
- SQLite DB (`events.db`) and uploaded images (`static/uploads/`) are created automatically
- Free PythonAnywhere accounts have 512 MB disk space — plenty for images
- The `/uploads/` folder is served as static files via Flask
